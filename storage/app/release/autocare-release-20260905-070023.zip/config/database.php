<?php
use Illuminate\Support\Str;
return ['default'=>env('DB_CONNECTION','mysql'),'connections'=>[
 'mysql'=>['driver'=>'mysql','url'=>env('DB_URL'),'host'=>env('DB_HOST','127.0.0.1'),'port'=>env('DB_PORT','3306'),'database'=>env('DB_DATABASE','autocare'),'username'=>env('DB_USERNAME','root'),'password'=>env('DB_PASSWORD',''),'unix_socket'=>env('DB_SOCKET',''),'charset'=>'utf8mb4','collation'=>'utf8mb4_unicode_ci','prefix'=>'','prefix_indexes'=>true,'strict'=>true,'engine'=>null,'options'=>extension_loaded('pdo_mysql')?array_filter([PDO::ATTR_EMULATE_PREPARES=>false]):[],],
 'sqlite'=>['driver'=>'sqlite','url'=>env('DB_URL'),'database'=>env('DB_DATABASE',database_path('database.sqlite')),'prefix'=>'','foreign_key_constraints'=>true],
], 'migrations'=>['table'=>'migrations','update_date_on_publish'=>true], 'redis'=>['client'=>env('REDIS_CLIENT','phpredis'),'default'=>['url'=>env('REDIS_URL'),'host'=>env('REDIS_HOST','127.0.0.1'),'username'=>env('REDIS_USERNAME'),'password'=>env('REDIS_PASSWORD'),'port'=>env('REDIS_PORT',6379),'database'=>env('REDIS_DB',0)]]];
